using UnityEngine;

public class gyroLook : MonoBehaviour
{
    [Header("Camera")]
    [Tooltip("Select the camera to control with the gyroscope")]
    public Transform playerCamera;

    private float initialPosY = 0f;
    private float initialPosGyroY = 0f;
    private float calibratedPosY = 0f;

    private Gyroscope gyro;
    private bool gyroActive;

    [Header("Calibration Settings")]
    [Tooltip("Do you want to perform the calibration on startup?")]
    public bool initialCalibration;
    [Tooltip("How long is the calibration, in seconds")]
    public float calibrationLength = 3.0f;


    void Start()
    {
        enableGyro();
        initialPosY = playerCamera.transform.eulerAngles.y;
    }

    void Update()
    {
        applyGyroRotation();
        applyCalibration();

        if(initialCalibration == true)
        {
            Invoke("calibratePosY", calibrationLength);
            initialCalibration = false;
        }
    }

    void enableGyro()
    {
        if (gyroActive)
            return;

        if (SystemInfo.supportsGyroscope)
        {
            gyro = Input.gyro;
            gyro.enabled = true;
            //playerCamera.transform.rotation = Quaternion.Euler(90f, 90f, 0f);

        }
        else
        {
            Debug.Log("Gyro not detected");
        }

        gyroActive = gyro.enabled;
    }

    void applyGyroRotation()
    {
        playerCamera.transform.rotation = gyro.attitude;
        playerCamera.transform.Rotate(0f, 0f, 180f, Space.Self);
        playerCamera.transform.Rotate(90f, 180f, 0f, Space.World);

        initialPosGyroY = playerCamera.transform.eulerAngles.y;
    }

    void calibratePosY()
    {
        calibratedPosY = initialPosGyroY - initialPosY;
    }

    void applyCalibration ()
    {
        playerCamera.transform.Rotate(0f, -calibratedPosY, 0f, Space.World);
    }
}
