using UnityEngine;
using System.Collections;
using System.Net;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using uPLibrary.Networking.M2Mqtt.Utility;
using uPLibrary.Networking.M2Mqtt.Exceptions;
using System;
using SimpleJSON;
using M2MqttUnity;

public class mqttBroker : MonoBehaviour
{
	private MqttClient client;
	// Use this for initialization
	private JSONNode jsonNode;
	private float x = 0;
	private float y = 0;
	private float z = 0;

	private Vector3 playerPosition;

	[Header("Player Settings")]
	[Tooltip("Finetune Step Division")]
	public float division = 1f;
	[Tooltip("Tag ID")]
	public string playerID = "dwm/node/0a93/uplink/location";
	[Tooltip("Player Height")]
	public float PlayerHeight = 1.6f;

	[Header("MQTT Broker Settings")]
	[Tooltip("Raspberry Pi IP Address")]
	public string clientIP = "192.168.1.184";
	[Tooltip("Unity Client ID")]
	public string clientID = "Unity";
	[Tooltip("Broker Port (1883 or 1885)")]
	public int clientPort = 1883;
	[Tooltip("Auth ID")]
	public string clientUser = "dwmuser";
	[Tooltip("Auth PW")]
	public string clientPass = "dwmpass";
	[Tooltip("Enable Encryption")]
	public bool isEncrypted = false;


	private void Start()
    {
		// create client instance
		//client = new MqttClient(IPAddress.Parse(clientIP), clientPort, isEncrypted, null, null, MqttSslProtocols.None);
		client = new MqttClient(clientIP);

		// register to message received
		client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

		// set credential for the mqtt connection
		client.Connect(clientID, clientUser, clientPass);

		// subscribe to the topics with QoS 2
		client.Subscribe(new string[] { playerID }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
	}

	void Update()
	{
		transformPlayer();
	}

	void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
	{
		string topic = e.Topic;
		string message = System.Text.Encoding.UTF8.GetString(e.Message);
		string json = JsonUtility.ToJson(message);
		jsonNode = SimpleJSON.JSON.Parse(message);

		if (topic == playerID)
		{
			x = float.Parse(jsonNode["position"]["x"]);
			y = float.Parse(jsonNode["position"]["y"]);
			z = float.Parse(jsonNode["position"]["z"]);

			Debug.Log("X: " + x + "\t Y: " + y + "\t Z: " + z);
		}
		 else
        {
			Debug.Log("Error - check player tag ID");
        }
	}

	void transformPlayer()
	{
		// player 1 transform position
		if (!float.IsNaN(x) && !float.IsNaN(y) && !float.IsNaN(z))
		{
			playerPosition = new Vector3(x / division, PlayerHeight, y / division);
			transform.position = playerPosition;
		}

	}
}
