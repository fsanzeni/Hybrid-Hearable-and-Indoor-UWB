using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class objectiveMove : MonoBehaviour
{
    [Header("Gizmo Settings")]
    public Color gizmoSphereColor = Color.yellow;

    public float gizmoSphereDiameter = .5f;

    public Color gizmoPathColor = Color.yellow;
    public bool showHandles = false;

    public List<Transform> waypoints = new List<Transform>();
    private int index = 0;

    public Transform objective;

    private Transform targetWaypoint;
    private int targetWaypointIndex = 0;
    private int lastWaypointIndex;

    void Start() 
    { 
        lastWaypointIndex = waypoints.Count - 1;
        targetWaypoint = waypoints[targetWaypointIndex];
    }

    void Update()
    {
        Transform[] tem = GetComponentsInChildren<Transform>();

        if (tem.Length > 0)
        {
            waypoints.Clear();

            index = 0;

            foreach (Transform t in tem)
            {
                if (t != transform)
                {
                    t.name = "WP_" + index.ToString();

                    waypoints.Add(t);

                    index++;
                }
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Cube")
        {
            Debug.Log("collision");
            Vector3 toGo = targetWaypoint.position;
            objective.position = toGo;
        }
    }

    void updateTargetWaypoint()
    {
        if (targetWaypointIndex > lastWaypointIndex)
        {
            targetWaypointIndex = 0;
        }

        targetWaypoint = waypoints[targetWaypointIndex];
    }

    private void OnDrawGizmos()
    {
#if UNITY_EDITOR
        if (waypoints.Count > 0)
        {
            Gizmos.color = gizmoSphereColor;

            foreach (Transform t in waypoints)
                Gizmos.DrawWireSphere(t.position, gizmoSphereDiameter);

            Gizmos.color = gizmoPathColor;
            for (int a = 0; a < waypoints.Count - 1; a++)
            {
                Gizmos.DrawLine(waypoints[a].position, waypoints[a + 1].position);

            }

            for (int i = 0; i < waypoints.Count; i++)
            {
                if (showHandles == true)
                {
                    Handles.Label(waypoints[i].transform.position, waypoints[i].ToString());
                    Handles.color = Color.black;
                }
            }
        }
#endif
    }

}

