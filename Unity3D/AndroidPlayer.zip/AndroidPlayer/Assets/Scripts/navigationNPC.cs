using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class navigationNPC : MonoBehaviour
{
    //public Transform destination;
    NavMeshAgent agent;

    public float interactionDistance = 10.0f;
    bool isClose;

    public Transform player;

    public List<Transform> waypoints = new List<Transform>();
    public float minDistanceToWaypoint = 0.1f;

    private Transform targetWaypoint;
    private int targetWaypointIndex = 0;
    private int lastWaypointIndex;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();

        lastWaypointIndex = waypoints.Count - 1;
        targetWaypoint = waypoints[targetWaypointIndex];
    }

    void Update()
    {
        float distToPlayer = Vector3.Distance(agent.transform.position, player.transform.position);
        
        if (distToPlayer <= interactionDistance)
        {
            isClose = true;
        } else
        {
            isClose = false;
        }

        float distToWaypoint = Vector3.Distance(agent.transform.position, targetWaypoint.position);
        checkDistanceToWaypoint(distToWaypoint);
        
        moveAgent(isClose);
        
    }

    void moveAgent(bool flag)
    {
        if (flag == true)
        {
            agent.SetDestination(player.transform.position);
            float distToPlayer = Vector3.Distance(agent.transform.position, player.transform.position);
            
            if (distToPlayer < 1)
            {
                this.agent.enabled = false;
            }
        }
        else
        {
            agent.SetDestination(targetWaypoint.transform.position);
        }
    }

    void checkDistanceToWaypoint(float currentDistance)
    {
        if (currentDistance <= minDistanceToWaypoint)
        {
            targetWaypointIndex++;
            updateTargetWaypoint();
        }
    }

    void updateTargetWaypoint()
    {
        if (targetWaypointIndex > lastWaypointIndex)
        {
            targetWaypointIndex = 0;
        }

        targetWaypoint = waypoints[targetWaypointIndex];
    }
}
