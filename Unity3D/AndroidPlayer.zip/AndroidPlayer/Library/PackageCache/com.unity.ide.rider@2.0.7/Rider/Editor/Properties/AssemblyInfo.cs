using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Unity.Rider.Editor")]
[assembly: InternalsVisibleTo("Unity.Rider.EditorTests")]
[assembly: InternalsVisibleTo("Unity.PackageValidationSuite.Editor")]
[assembly: InternalsVisibleTo("Assembly-CSharp-Editor")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]

[assembly: AssemblyVersion("1.0.0")]
